<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}


if (isset($_GET['idprograma'])) {
    $idprograma = $_GET['idprograma'];
    $resultado = mysqli_query($conn, "SELECT * FROM programa WHERE idprograma = $idprograma");
    $programas = mysqli_fetch_assoc($resultado);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idprograma = $_POST['idprograma'];
    $nombreprograma = mysqli_real_escape_string($conn, $_POST['nombreprograma']);
    $sql = "UPDATE programa SET nombreprograma = '$nombreprograma' WHERE idprograma = $idprograma";
    if (mysqli_query($conn, $sql)) {
        header("Location: programa.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Modificar Programa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <?php include 'barraDeNavegacion.php'; ?>

    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="card shadow p-4" style="width: 100%; max-width: 500px;">
            <h2 class="text-center mb-4">Modificar Programa</h2>

            <form method="POST">
                <input type="hidden" name="idprograma" value="<?php echo $programas['idprograma']; ?>">

                <!-- ID (solo lectura) -->
                <div class="mb-3">
                    <label class="form-label">ID del programa</label>
                    <input type="text" class="form-control" value="<?php echo $programas['idprograma']; ?>" readonly>
                </div>

                <!-- Nombre del programa -->
                <div class="mb-3">
                    <label class="form-label">Nombre del programa</label>
                    <input type="text" name="nombreprograma" class="form-control" value="<?php echo $programas['nombreprograma']; ?>" required>
                </div>

                <!-- Botones -->
                <div class="d-flex gap-2">
                    <a href="programa.php" class="btn btn-outline-secondary w-50">Cancelar</a>
                    <button type="submit" class="btn btn-primary w-50">Actualizar</button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
