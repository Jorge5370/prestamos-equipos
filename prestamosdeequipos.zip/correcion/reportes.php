<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reportes de Préstamos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            border-radius: 15px 15px 0 0 !important;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: white;
        }
        .btn-export {
            border-radius: 50px;
            padding: 10px 25px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-pdf {
            background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
            border: none;
        }
        .btn-excel {
            background: linear-gradient(135deg, #1d976c 0%, #93f9b9 100%);
            border: none;
        }
        .icon-box {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }
        .title {
            color: #343a40;
            font-weight: 700;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.1);
        }
        .subtitle {
            color: #6c757d;
            font-weight: 400;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row mb-5">
            <div class="col-12 text-center">
                <h1 class="title">Reportes de Préstamos</h1>
                <p class="subtitle">Genera informes detallados de los préstamos realizados</p>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header text-center">
                        <div class="icon-box">
                            <i class="fas fa-file-pdf"></i>
                        </div>
                        <h3>Reporte en PDF</h3>
                    </div>
                    <div class="card-body text-center">
                        <p class="card-text">Genera un documento PDF con el listado completo de préstamos, ideal para imprimir o compartir.</p>
                        <a href="reportes_pdf.php" class="btn btn-pdf btn-export text-white">
                            <i class="fas fa-download me-2"></i>Descargar PDF
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header text-center">
                        <div class="icon-box">
                            <i class="fas fa-file-excel"></i>
                        </div>
                        <h3>Reporte en Excel</h3>
                    </div>
                    <div class="card-body text-center">
                        <p class="card-text">Exporta los datos a formato Excel para su análisis y procesamiento en hojas de cálculo.</p>
                        <a href="reportes_Excel.php" class="btn btn-excel btn-export text-white">
                            <i class="fas fa-download me-2"></i>Descargar Excel
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0"><i class="fas fa-info-circle me-2"></i>Información sobre los reportes</h4>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <strong><i class="fas fa-lightbulb me-2"></i>Tip:</strong> 
                            Los reportes incluyen toda la información de préstamos, equipos, aprendices y usuarios.
                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>PDF: Documento formateado para impresión</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Excel: Datos crudos para análisis</li>
                            <li class="list-group-item"><i class="fas fa-sync-alt text-primary me-2"></i>Los datos se generan en tiempo real</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>