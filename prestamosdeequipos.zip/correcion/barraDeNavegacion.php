<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    .nav-link {
      position: relative;
      padding-bottom: 4px;
      transition: color 0.3s;
    }

    .nav-link::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: 0;
      width: 0;
      height: 2px;
      background-color: #0d6efd;
      transition: width 0.3s;
    }

    .nav-link:hover {
      color: #0d6efd;
    }

    .nav-link:hover::after {
      width: 100%;
    }

    .navbar {
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
    }

    .navbar-nav .nav-item {
      margin: 0 0.25rem;
    }

    .btn-logout {
      border-radius: 50rem;
      padding: 0.375rem 1rem;
      font-weight: 500;
    }
  </style>
</head>

<body>

  <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top border-bottom border-2 border-light">
    <div class="container-fluid">
      <a class="navbar-brand fw-bold text-primary" href="index.php">Préstamos de Equipo</a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent"
        aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-center" id="navbarContent">
        <ul class="navbar-nav">
          <li class="nav-item"><a class="nav-link" href="aprendiz_listar.php">Aprendices</a></li>
          <li class="nav-item"><a class="nav-link" href="categoria.php">Categorías</a></li>
          <li class="nav-item"><a class="nav-link" href="equipo_listar.php">Equipos</a></li>
          <li class="nav-item"><a class="nav-link" href="ficha_listar.php">Fichas</a></li>
          <li class="nav-item"><a class="nav-link" href="prestamos.php">Préstamos</a></li>
          <li class="nav-item"><a class="nav-link" href="programa.php">Programas</a></li>
          <li class="nav-item"><a class="nav-link" href="usuario_listar.php">Usuarios</a></li>
        </ul>
      </div>

      <div class="d-flex">
        <a href="cerrarSesion.php" class="btn btn-outline-danger btn-logout">Cerrar sesión</a>
      </div>
    </div>
  </nav>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
