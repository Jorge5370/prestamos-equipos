<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}


if (isset($_GET['idcategoria'])) {
    $idcategoria = $_GET['idcategoria'];
    $resultado = mysqli_query($conn, "SELECT * FROM categorias WHERE idcategoria = $idcategoria");
    $categorias = mysqli_fetch_assoc($resultado);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idcategoria = $_POST['idcategoria'];
    $descripcion = mysqli_real_escape_string($conn, $_POST['descripcion']);
    $sql = "UPDATE categorias SET descripcion = '$descripcion' WHERE idcategoria = $idcategoria";
    if (mysqli_query($conn, $sql)) {
        header("Location: categoria.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Modificar Categoria</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <?php include 'barraDeNavegacion.php'; ?>

    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="card shadow p-4" style="width: 100%; max-width: 500px;">
            <h2 class="text-center mb-4">Modificar Categoria</h2>

            <form method="POST">
                <input type="hidden" name="idcategoria" value="<?php echo $categorias['idcategoria']; ?>">

                <!-- ID (solo lectura) -->
                <div class="mb-3">
                    <label class="form-label">ID de la categoria</label>
                    <input type="text" class="form-control" value="<?php echo $categorias['idcategoria']; ?>" readonly>
                </div>

                <!-- Nombre del programa -->
                <div class="mb-3">
                    <label class="form-label">Nombre de la categoria</label>
                    <input type="text" name="descripcion" class="form-control" value="<?php echo $categorias['descripcion']; ?>" required>
                </div>

                <!-- Botones -->
                <div class="d-flex gap-2">
                    <a href="categoria.php" class="btn btn-outline-secondary w-50">Cancelar</a>
                    <button type="submit" class="btn btn-primary w-50">Actualizar</button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
