<?php

include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}


if (isset($_GET['usuario'])) {
    $usuario = $_GET['usuario'];
    

    $sql = "DELETE FROM usuarios WHERE usuario = '$usuario'";
    if (mysqli_query($conn, $sql)) {
        header("Location: usuario_listar.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} 

?>