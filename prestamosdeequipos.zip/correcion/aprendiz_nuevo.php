<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idaprendiz = $_POST['idaprendiz'];
    $tipodoc = $_POST['tipodoc'];
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $celular = $_POST['celular'];
    $email = $_POST['email'];
    $nficha = $_POST['nficha'];

    $sql = "INSERT INTO aprendiz (idaprendiz, tipodoc, nombres, apellidos, celular, email, nficha)
            VALUES ('$idaprendiz', '$tipodoc', '$nombres', '$apellidos', '$celular', '$email', '$nficha')";

    if (mysqli_query($conn, $sql)) {
        header("Location: aprendiz_listar.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Nuevo Aprendiz</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <?php include 'barraDeNavegacion.php'; ?>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">

                <!-- Card tipo Modificar Equipo -->
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h3 class="text-center mb-4">Nuevo Aprendiz</h3>

                        <form method="post">
                            <!-- ID Aprendiz -->
                            <div class="mb-3">
                                <label class="form-label">ID Aprendiz</label>
                                <input type="text" name="idaprendiz" class="form-control" required>
                            </div>

                            <!-- Tipo Documento -->
                            <div class="mb-3">
                                <label class="form-label">Tipo de Documento</label>
                                <select name="tipodoc" class="form-select" required>
                                    <option value="" disabled selected>-- Selecciona --</option>
                                    <option value="CC">Cédula de Ciudadanía</option>
                                    <option value="TI">Tarjeta de Identidad</option>
                                    <option value="CE">Cédula de Extranjería</option>
                                </select>
                            </div>

                            <!-- Nombres -->
                            <div class="mb-3">
                                <label class="form-label">Nombres</label>
                                <input type="text" name="nombres" class="form-control" required>
                            </div>

                            <!-- Apellidos -->
                            <div class="mb-3">
                                <label class="form-label">Apellidos</label>
                                <input type="text" name="apellidos" class="form-control" required>
                            </div>

                            <!-- Celular -->
                            <div class="mb-3">
                                <label class="form-label">Celular</label>
                                <input type="text" name="celular" class="form-control" required>
                            </div>

                            <!-- Email -->
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>

                            <!-- Ficha -->
                            <div class="mb-4">
                                <label class="form-label">Número de Ficha</label>
                                <select name="nficha" class="form-select" required>
                                    <option value="" disabled selected>-- Selecciona una ficha --</option>
                                    <?php
                                    $fichas = mysqli_query($conn, "SELECT nficha FROM ficha ORDER BY nficha");
                                    while ($ficha = mysqli_fetch_assoc($fichas)) {
                                        echo "<option value='{$ficha['nficha']}'>{$ficha['nficha']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <!-- Botones -->
                            <div class="d-flex justify-content-between">
                                <a href="aprendiz_listar.php" class="btn btn-outline-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
