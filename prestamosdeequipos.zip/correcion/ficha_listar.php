<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Búsqueda
$busqueda = isset($_GET['buscar']) ? mysqli_real_escape_string($conn, $_GET['buscar']) : '';
$where = $busqueda !== '' ? "WHERE f.nficha LIKE '%$busqueda%' OR p.nombreprograma LIKE '%$busqueda%'" : '';

// Paginación
$registros_por_pagina = 5;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($pagina_actual - 1) * $registros_por_pagina;

// Total de registros
$total_query = mysqli_query($conn, "
    SELECT COUNT(*) AS total 
    FROM ficha f 
    INNER JOIN programa p ON f.idprograma = p.idprograma
    $where
");
$total_filas = mysqli_fetch_assoc($total_query)['total'];
$total_paginas = max(1, ceil($total_filas / $registros_por_pagina));

// Consulta principal
$fichas = mysqli_query($conn, "
    SELECT f.nficha, p.nombreprograma
    FROM ficha f
    INNER JOIN programa p ON f.idprograma = p.idprograma
    $where
    ORDER BY f.nficha ASC
    LIMIT $inicio, $registros_por_pagina
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de Fichas</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include 'barraDeNavegacion.php'; ?>

<div class="container py-5">
    <h2 class="text-center mb-4">Listado de Fichas</h2>

    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div>
            <a href="index.php" class="btn btn-outline-secondary">Volver al Menú</a>
            <a href="ficha.php" class="btn btn-primary">➕ Nueva Ficha</a>
        </div>
        <form method="get" class="d-flex">
            <input type="text" name="buscar" class="form-control me-2" placeholder="Buscar..." value="<?= htmlspecialchars($busqueda) ?>">
            <input type="hidden" name="pagina" value="1">
            <button class="btn btn-outline-success" type="submit">Buscar</button>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped text-center align-middle">
            <thead class="table-primary">
                <tr>
                    <th>Número de Ficha</th>
                    <th>Programa</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($fichas) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($fichas)) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row['nficha']) ?></td>
                            <td><?= htmlspecialchars($row['nombreprograma']) ?></td>
                            <td>
                                <a href="ficha_modificar.php?nficha=<?= urlencode($row['nficha']) ?>" class="btn btn-warning btn-sm">✏️ Editar</a>
                                <a href="ficha_eliminar.php?nficha=<?= urlencode($row['nficha']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar esta ficha?')">🗑️ Eliminar</a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3" class="text-muted">No hay fichas para mostrar</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Paginación -->
    <nav class="mt-4">
        <ul class="pagination justify-content-center">
            <?php if ($pagina_actual > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?pagina=<?= $pagina_actual - 1 ?>&buscar=<?= urlencode($busqueda) ?>">Anterior</a>
                </li>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                <li class="page-item <?= $i == $pagina_actual ? 'active' : '' ?>">
                    <a class="page-link" href="?pagina=<?= $i ?>&buscar=<?= urlencode($busqueda) ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($pagina_actual < $total_paginas): ?>
                <li class="page-item">
                    <a class="page-link" href="?pagina=<?= $pagina_actual + 1 ?>&buscar=<?= urlencode($busqueda) ?>">Siguiente</a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
