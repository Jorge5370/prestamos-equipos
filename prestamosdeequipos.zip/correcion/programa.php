<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}


// Variables para búsqueda y paginación
$busqueda = isset($_GET['busqueda']) ? trim($_GET['busqueda']) : '';
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$registrosPorPagina = 5;
$offset = ($pagina - 1) * $registrosPorPagina;

// Procesar inserción de nuevo programa
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombreprograma = trim($_POST['nombreprograma']);
    if ($nombreprograma) {
        $stmt = $conn->prepare("INSERT INTO programa (nombreprograma) VALUES (?)");
        $stmt->bind_param("s", $nombreprograma);
        $stmt->execute();
        $stmt->close();
    }
}

// Filtro de búsqueda
$where = $busqueda ? "WHERE nombreprograma LIKE '%" . $conn->real_escape_string($busqueda) . "%'" : "";

// Obtener total de programas para la paginación
$totalQuery = $conn->query("SELECT COUNT(*) AS total FROM programa $where");
$total = $totalQuery->fetch_assoc()['total'];
$totalPaginas = ceil($total / $registrosPorPagina);

// Obtener lista filtrada
$resultado = $conn->query("SELECT * FROM programa $where ORDER BY idprograma ASC LIMIT $offset, $registrosPorPagina");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Gestión de Programas</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include 'barraDeNavegacion.php' ?>


<div class="container py-4">

    <!-- Volver al menú -->
    <div class="mb-3">
        <a href="index.php" class="btn btn-secondary btn-sm">Volver al Menú</a>
    </div>

    <h2 class="text-center mb-4">Gestión de Programas</h2>

    <!-- Formulario para agregar nuevo programa -->
    <div class="card p-4 mb-4 shadow-sm">
        <h5 class="mb-3">Agregar Nuevo Programa</h5>
        <form method="post">
            <input type="text" class="form-control mb-3" name="nombreprograma" placeholder="Nombre del Programa" required>
            <button type="submit" class="btn btn-primary w-100">Guardar Programa</button>
        </form>
    </div>

    <!-- Buscador -->
    <form class="row mb-3" method="get">
        <div class="col-10">
            <input type="text" class="form-control" name="busqueda" value="<?= htmlspecialchars($busqueda) ?>" placeholder="Buscar programa por nombre...">
        </div>
        <div class="col-2">
            <button class="btn btn-outline-primary w-100" type="submit">Buscar</button>
        </div>
    </form>

    <!-- Tabla de programas -->
    <h4 class="text-center mb-3">Lista de Programas</h4>
    <div class="table-responsive mb-3">
        <table class="table table-bordered table-striped text-center align-middle">
            <thead class="table-primary">
                <tr>
                    <th>ID Programa</th>
                    <th>Nombre del Programa</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($resultado->num_rows > 0): ?>
                    <?php while ($fila = $resultado->fetch_assoc()): ?>
                        <tr>
                            <td><?= $fila['idprograma'] ?></td>
                            <td><?= htmlspecialchars($fila['nombreprograma']) ?></td>
                            <td><a href="programa_editar.php?idprograma=<?= urlencode($fila['idprograma']) ?>" class="btn btn-sm btn-warning me-1">✏️ Editar</a></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="2" class="text-muted">No se encontraron programas.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Paginación -->
    <nav class="text-center">
        <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                <li class="page-item <?= $i == $pagina ? 'active' : '' ?>">
                    <a class="page-link" href="?pagina=<?= $i ?>&busqueda=<?= urlencode($busqueda) ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>


</div>

</body>
</html>
<?php $conn->close(); ?>
