<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}


$mensaje = "";
$claseMensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nficha = trim($_POST['nficha']);
    $idprograma = intval($_POST['idprograma']);

    if (!empty($nficha) && $idprograma > 0) {
        $insertarFicha = $conn->prepare(
            "INSERT INTO ficha (nficha, idprograma) VALUES (?, ?)"
        );
        $insertarFicha->bind_param("si", $nficha, $idprograma);

        if ($insertarFicha->execute()) {
            $mensaje = "Datos guardados correctamente.";
            $claseMensaje = "alert-success";
        } else {
            $mensaje = "Error al guardar datos: " . $insertarFicha->error;
            $claseMensaje = "alert-danger";
        }
        $insertarFicha->close();
    } else {
        $mensaje = "Por favor, completa todos los campos correctamente.";
        $claseMensaje = "alert-warning";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Nueva Ficha</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<?php include 'barraDeNavegacion.php'; ?>

<body class="bg-light">

    <div class="container d-flex align-items-center justify-content-center min-vh-100">
        <div class="col-12 col-sm-8 col-md-6 col-lg-5">
            <div class="card p-4 shadow-sm rounded-2">
                <h2 class="mb-4 text-center">Nueva Ficha</h2>

                <?php if ($mensaje): ?>
                    <div class="alert <?= $claseMensaje ?> text-center"><?= $mensaje ?></div>
                <?php endif; ?>

                <form method="post" action="">
                    <div class="mb-3">
                        <label class="form-label">Número de Ficha</label>
                        <input type="text" class="form-control" name="nficha" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Programa</label>
                        <select class="form-select" name="idprograma" required>
                            <option value="">-- Selecciona un programa --</option>
                            <?php
                            $result = $conn->query("SELECT idprograma, nombreprograma FROM programa ORDER BY nombreprograma");
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='{$row['idprograma']}'>{$row['nombreprograma']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="ficha_listar.php" class="btn btn-outline-secondary">Cancelar</a>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
