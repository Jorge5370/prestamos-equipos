<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['idprestamos'])) {
    echo "ID de préstamo no especificado.";
    exit;
}

$idprestamos = $_GET['idprestamos'];
$consulta = "SELECT p.*, a.nombres, a.apellidos, e.nombre AS equipo_nombre FROM prestamos p 
             JOIN aprendiz a ON p.idaprendiz = a.idaprendiz 
             JOIN equipo e ON p.idequipo = e.idequipo 
             WHERE p.idprestamos = '$idprestamos'";
$resultado = mysqli_query($conn, $consulta);
$prestamo = mysqli_fetch_assoc($resultado);

if (!$prestamo) {
    echo "Préstamo no encontrado.";
    exit;
}

// Actualizar al enviar el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fechamaxima = $_POST['fechamaxima'];
    $fechadevolucion = $_POST['fechadevolucion'];
    $estadoentrega = $_POST['estadoentrega'];
    $estadodevolucion = $_POST['estadodevolucion'];

    $sql = "UPDATE prestamos SET 
                fechamaxima = ?, 
                fechadevolucion = ?, 
                estadoentrega = ?, 
                estadodevolucion = ?
            WHERE idprestamos = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param(
        $stmt,
        "ssssi",
        $fechamaxima,
        $fechadevolucion,
        $estadoentrega,
        $estadodevolucion,
        $idprestamos
    );

    if (mysqli_stmt_execute($stmt)) {
        header("Location: prestamos.php");
        exit;
    } else {
        echo "Error al actualizar: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Modificar Préstamo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <?php include 'barraDeNavegacion.php'; ?>
    <br>

    <div class="container d-flex align-items-center justify-content-center">
        <div class="col-12 col-sm-8 col-md-6">
            <div class="card p-4 shadow-sm rounded-2">
                <h2 class="text-center mb-4">Modificar Préstamo</h2>

                <form method="POST">

                    <!-- EQUIPO (no editable) -->
                    <div class="mb-3">
                        <label class="form-label">Equipo</label>
                        <input type="text" class="form-control" value="<?= $prestamo['equipo_nombre'] ?>" disabled>
                        <input type="hidden" name="idequipo" value="<?= $prestamo['idequipo'] ?>">
                    </div>

                    <!-- APRENDIZ (no editable) -->
                    <div class="mb-3">
                        <label class="form-label">Aprendiz</label>
                        <input type="text" class="form-control" value="<?= $prestamo['nombres'] . ' ' . $prestamo['apellidos'] ?>" disabled>
                        <input type="hidden" name="idaprendiz" value="<?= $prestamo['idaprendiz'] ?>">
                    </div>

                    <!-- FECHA MÁXIMA -->
                    <div class="mb-3">
                        <label class="form-label">Fecha Máxima</label>
                        <input type="datetime-local" name="fechamaxima" class="form-control" value="<?= date('Y-m-d\TH:i', strtotime($prestamo['fechamaxima'])) ?>" required>
                    </div>

                    <!-- FECHA DEVOLUCIÓN -->
                    <div class="mb-3">
                        <label class="form-label">Fecha Devolución</label>
                        <input type="datetime-local" name="fechadevolucion" class="form-control" value="<?= $prestamo['fechadevolucion'] ? date('Y-m-d\TH:i', strtotime($prestamo['fechadevolucion'])) : '' ?>">
                    </div>

                    <!-- ESTADO ENTREGA -->
                    <div class="mb-3">
                        <label class="form-label">Estado Entrega</label>
                        <select name="estadoentrega" class="form-select" required>
                            <option <?= $prestamo['estadoentrega'] == 'Entregado' ? 'selected' : '' ?>>Entregado</option>
                            <option <?= $prestamo['estadoentrega'] == 'Pendiente' ? 'selected' : '' ?>>Pendiente</option>
                        </select>
                    </div>

                    <!-- ESTADO DEVOLUCIÓN -->
                    <div class="mb-3">
                        <label class="form-label">Estado Devolución</label>
                        <select name="estadodevolucion" class="form-select" required>
                            <option <?= $prestamo['estadodevolucion'] == 'Pendiente' ? 'selected' : '' ?>>Pendiente</option>
                            <option <?= $prestamo['estadodevolucion'] == 'Devuelto' ? 'selected' : '' ?>>Devuelto</option>
                        </select>
                    </div>

                    <!-- USUARIO (no editable) -->
                    <div class="mb-4">
                        <label class="form-label">Registrado por</label>
                        <input type="text" class="form-control" value="<?= $prestamo['usuario'] ?>" disabled>
                        <input type="hidden" name="usuario" value="<?= $prestamo['usuario'] ?>">
                    </div>

                    <!-- BOTONES -->
                    <div class="d-flex justify-content-between">
                        <a href="prestamos.php" class="btn btn-outline-secondary">Cancelar</a>
                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <br>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>

</html>
