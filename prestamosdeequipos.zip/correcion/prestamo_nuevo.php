<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$mensaje = "";
$clase = "";
$préstamoPendiente = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idequipo = $_POST['idequipo'];
    $idaprendiz = $_POST['idaprendiz'];
    $fechamaxima = $_POST['fechamaxima'];
    $fechadevolucion = $_POST['fechadevolucion'];
    $estadoentrega = $_POST['estadoentrega'];
    $estadodevolucion = $_POST['estadodevolucion'];
    $usuario = $_SESSION['usuario']; // Usuario logueado

    // Verificar si el equipo ya está prestado y no se ha devuelto
    $verificar = mysqli_query($conn, "SELECT p.*, a.nombres, a.apellidos 
                                      FROM prestamos p
                                      JOIN aprendiz a ON p.idaprendiz = a.idaprendiz
                                      WHERE p.idequipo = '$idequipo' 
                                      AND p.estadodevolucion = 'Pendiente'");

    if (mysqli_num_rows($verificar) > 0) {
        $préstamoPendiente = mysqli_fetch_assoc($verificar);
        $mensaje = "Este equipo aún no ha sido devuelto. No se puede registrar otro préstamo.";
        $clase = "danger";
    } else {
        $sql = "INSERT INTO prestamos (idequipo, idaprendiz, fecha, fechamaxima, fechadevolucion, estadoentrega, estadodevolucion, usuario) 
                VALUES (?, ?, NOW(), ?, ?, ?, ?, ?)";
        $consulta = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param(
            $consulta,
            "sssssss",
            $idequipo,
            $idaprendiz,
            $fechamaxima,
            $fechadevolucion,
            $estadoentrega,
            $estadodevolucion,
            $usuario
        );

        if (mysqli_stmt_execute($consulta)) {
            $mensaje = "Préstamo registrado correctamente.";
            $clase = "success";
        } else {
            $mensaje = "Error: " . mysqli_error($conn);
            $clase = "danger";
        }

        mysqli_stmt_close($consulta);
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Registrar Préstamo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <?php include 'barraDeNavegacion.php'; ?>

    <br>

    <div class="container d-flex align-items-center justify-content-center ">
        <div class="col-12 col-sm-8 col-md-6 ">
            <div class="card p-4 shadow-sm rounded-2">
                <h2 class="mb-4 text-center">Registrar Préstamo</h2>

                <?php if (!empty($mensaje)) : ?>
                    <div class="alert alert-<?= $clase ?> text-center"><?= $mensaje ?></div>
                <?php endif; ?>

                <?php if ($préstamoPendiente) : ?>
                    <div class="alert alert-warning mt-3">
                        <strong>Detalle del préstamo pendiente:</strong>
                        <ul>
                            <li><strong>Aprendiz:</strong> <?= $préstamoPendiente['nombres'] . ' ' . $préstamoPendiente['apellidos'] ?></li>
                            <li><strong>Fecha del préstamo:</strong> <?= $préstamoPendiente['fecha'] ?></li>
                            <li><strong>Fecha máxima:</strong> <?= $préstamoPendiente['fechamaxima'] ?></li>
                            <li><strong>Registrado por:</strong> <?= $préstamoPendiente['usuario'] ?></li>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST">

                    <!-- Equipo -->
                    <div class="mb-3">
                        <label class="form-label">Equipo</label>
                        <select name="idequipo" class="form-select" required>
                            <option value="">Seleccione un equipo</option>
                            <?php
                            $equipos = mysqli_query($conn, "SELECT idequipo, nombre FROM equipo ORDER BY nombre");
                            while ($e = mysqli_fetch_assoc($equipos)) {
                                echo "<option value='{$e['idequipo']}'>{$e['nombre']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <!-- Aprendiz -->
                    <div class="mb-3">
                        <label class="form-label">Aprendiz</label>
                        <select name="idaprendiz" class="form-select" required>
                            <option value="">Seleccione un aprendiz</option>
                            <?php
                            $aprendices = mysqli_query($conn, "SELECT idaprendiz, nombres, apellidos FROM aprendiz ORDER BY nombres");
                            while ($a = mysqli_fetch_assoc($aprendices)) {
                                echo "<option value='{$a['idaprendiz']}'>{$a['nombres']} {$a['apellidos']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <!-- Fecha Préstamo -->
                    <div class="mb-3">
                        <label class="form-label">Fecha Préstamo</label>
                        <input type="text" class="form-control" value="<?= date('Y-m-d H:i:s') ?>" readonly>
                    </div>

                    <!-- Fecha Devolución -->
                    <div class="mb-3">
                        <label class="form-label">Fecha Devolución </label>
                        <input type="datetime-local" name="fechadevolucion" class="form-control">
                    </div>

                    <!-- Fecha Máxima -->
                    <div class="mb-3">
                        <label class="form-label">Fecha Máxima de aplazamiento</label>
                        <input type="datetime-local" name="fechamaxima" class="form-control" required>
                    </div>

                    <!-- Estado Entrega -->
                    <div class="mb-3">
                        <label class="form-label">Estado Entrega</label>
                        <select name="estadoentrega" class="form-select" required>
                            <option value="Entregado">Entregado</option>
                            <option value="Pendiente">Pendiente</option>
                        </select>
                    </div>

                    <!-- Estado Devolución -->
                    <div class="mb-3">
                        <label class="form-label">Estado Devolución</label>
                        <select name="estadodevolucion" class="form-select" required>
                            <option value="Pendiente">Pendiente</option>
                            <option value="Devuelto">Devuelto</option>
                        </select>
                    </div>

                    <!-- Botones -->
                    <div class="d-flex justify-content-between">
                        <a href="prestamos.php" class="btn btn-outline-secondary">Cancelar</a>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <br>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>