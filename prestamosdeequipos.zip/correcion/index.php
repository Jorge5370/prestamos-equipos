<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Obtener información del usuario
$usuario_actual = $_SESSION['usuario'];
$sql_usuario = "SELECT * FROM usuarios WHERE usuario = '$usuario_actual'";
$result_usuario = mysqli_query($conn, $sql_usuario);
$usuario = mysqli_fetch_assoc($result_usuario);

// Obtener estadísticas reales de la base de datos
$stats = [
    'aprendices' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM aprendiz"))['total'],
    'equipos' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM equipo"))['total'],
    'prestamos_activos' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM prestamos WHERE estadodevolucion = 'Pendiente'"))['total'],
    'prestamos_vencidos' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM prestamos WHERE estadodevolucion = 'Pendiente' AND fechamaxima < NOW()"))['total'],
    'categorias' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM categorias"))['total'],
    'fichas' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM ficha"))['total'],
    'programas' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM programa"))['total'],
    'usuarios' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM usuarios"))['total']
];

// Obtener préstamos recientes
$sql_prestamos = "SELECT p.idprestamos, e.nombre AS equipo, CONCAT(a.nombres, ' ', a.apellidos) AS aprendiz, 
                 p.fecha, p.fechamaxima, p.estadodevolucion
                 FROM prestamos p
                 INNER JOIN equipo e ON p.idequipo = e.idequipo
                 INNER JOIN aprendiz a ON p.idaprendiz = a.idaprendiz
                 ORDER BY p.fecha DESC LIMIT 5";
$result_prestamos = mysqli_query($conn, $sql_prestamos);

// Saludo según hora del día
$saludo = "Bienvenido";
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Sistema de Préstamos SENA</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-color: #0d6efd;
            --secondary-color: #1a5cb0;
            --success-color: #198754;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --info-color: #0dcaf0;
            --dark-color: #212529;
            --light-color: #f8f9fa;
            --card-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            --transition: all 0.3s ease;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8fafc;
            color: var(--dark-color);
        }

        .dashboard-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border-radius: 10px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--card-shadow);
        }

        .user-greeting {
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .user-role {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 0.25rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 500;
            display: inline-block;
        }

        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: var(--card-shadow);
            transition: var(--transition);
            height: 100%;
            border-left: 4px solid var(--primary-color);
        }

        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .stats-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }

        .stats-value {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .stats-label {
            font-size: 0.9rem;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .module-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: var(--card-shadow);
            transition: var(--transition);
            height: 100%;
            text-align: center;
            position: relative;
            overflow: hidden;
            border-top: 3px solid var(--primary-color);
        }

        .module-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(13, 110, 253, 0.15);
        }

        .module-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }

        .module-title {
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
        }

        .module-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 0.7rem;
        }

        .recent-loans {
            background: white;
            border-radius: 10px;
            box-shadow: var(--card-shadow);
            overflow: hidden;
        }

        .status-badge {
            padding: 0.35rem 0.75rem;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .status-active {
            background-color: rgba(25, 135, 84, 0.1);
            color: var(--success-color);
        }

        .status-pending {
            background-color: rgba(255, 193, 7, 0.1);
            color: var(--warning-color);
        }

        .status-overdue {
            background-color: rgba(220, 53, 69, 0.1);
            color: var(--danger-color);
        }

        .wave-decoration {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 100px;
            background: url('data:image/svg+xml;utf8,<svg viewBox="0 0 1200 120" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none"><path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" fill="%230d6efd" opacity=".05"/><path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" fill="%230d6efd" opacity=".1"/></svg>');
            background-size: cover;
            background-repeat: no-repeat;
            z-index: -1;
        }
    </style>
</head>

<body>
    <?php include 'barraDeNavegacion.php' ?>

    <div class="container py-4">
        <!-- Encabezado con saludo -->
        <div class="dashboard-header">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="user-greeting"><?= $saludo ?>, <?= htmlspecialchars($usuario['nombre']) ?></h1>
                    <span class="user-role"><?= ucfirst($usuario['usuario']) ?></span>
                </div>
            </div>
        </div>

        <!-- Estadísticas rápidas -->
        <div class="row mb-4 g-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <i class="bi bi-people-fill stats-icon"></i>
                    <div class="stats-value"><?= $stats['aprendices'] ?></div>
                    <div class="stats-label">Aprendices</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <i class="bi bi-laptop stats-icon"></i>
                    <div class="stats-value"><?= $stats['equipos'] ?></div>
                    <div class="stats-label">Equipos</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <i class="bi bi-arrow-down-up stats-icon"></i>
                    <div class="stats-value"><?= $stats['prestamos_activos'] ?></div>
                    <div class="stats-label">Préstamos activos</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <i class="bi bi-exclamation-triangle stats-icon"></i>
                    <div class="stats-value"><?= $stats['prestamos_vencidos'] ?></div>
                    <div class="stats-label">Vencidos</div>
                </div>
            </div>
        </div>

        <!-- Módulos del sistema -->
        <h3 class="mb-4 fw-bold">Módulos del sistema</h3>
        <div class="row g-4 mb-4">
            <!-- Aprendices -->
            <div class="col-md-3">
                <a href="aprendiz_listar.php" class="text-decoration-none text-dark">
                    <div class="module-card">
                        <i class="bi bi-people-fill module-icon"></i>
                        <h5 class="module-title">Aprendices</h5>
                        <p class="text-muted small">Gestión de aprendices</p>
                        <span class="badge bg-primary module-badge"><?= $stats['aprendices'] ?> reg.</span>
                    </div>
                </a>
            </div>

            <!-- Equipos -->
            <div class="col-md-3">
                <a href="equipo_listar.php" class="text-decoration-none text-dark">
                    <div class="module-card">
                        <i class="bi bi-laptop module-icon"></i>
                        <h5 class="module-title">Equipos</h5>
                        <p class="text-muted small">Inventario de equipos</p>
                        <span class="badge bg-success module-badge"><?= $stats['equipos'] ?> disp.</span>
                    </div>
                </a>
            </div>

            <!-- Préstamos -->
            <div class="col-md-3">
                <a href="prestamos.php" class="text-decoration-none text-dark">
                    <div class="module-card">
                        <i class="bi bi-arrow-down-up module-icon"></i>
                        <h5 class="module-title">Préstamos</h5>
                        <p class="text-muted small">Registro y seguimiento</p>
                        <span class="badge bg-warning text-dark module-badge"><?= $stats['prestamos_activos'] ?> act.</span>
                    </div>
                </a>
            </div>

            <!-- Categorías -->
            <div class="col-md-3">
                <a href="categoria.php" class="text-decoration-none text-dark">
                    <div class="module-card">
                        <i class="bi bi-tags-fill module-icon"></i>
                        <h5 class="module-title">Categorías</h5>
                        <p class="text-muted small">Clasificación de equipos</p>
                        <span class="badge bg-info module-badge"><?= $stats['categorias'] ?> cat.</span>
                    </div>
                </a>
            </div>

            <!-- Fichas -->
            <div class="col-md-3">
                <a href="ficha_listar.php" class="text-decoration-none text-dark">
                    <div class="module-card">
                        <i class="bi bi-card-list module-icon"></i>
                        <h5 class="module-title">Fichas</h5>
                        <p class="text-muted small">Gestión de fichas</p>
                        <span class="badge bg-secondary module-badge"><?= $stats['fichas'] ?> fichas</span>
                    </div>
                </a>
            </div>

            <!-- Programas -->
            <div class="col-md-3">
                <a href="programa.php" class="text-decoration-none text-dark">
                    <div class="module-card">
                        <i class="bi bi-journal-text module-icon"></i>
                        <h5 class="module-title">Programas</h5>
                        <p class="text-muted small">Programas de formación</p>
                        <span class="badge bg-primary module-badge"><?= $stats['programas'] ?> prog.</span>
                    </div>
                </a>
            </div>

            <!-- Usuarios -->
            <div class="col-md-3">
                <a href="usuario_listar.php" class="text-decoration-none text-dark">
                    <div class="module-card">
                        <i class="bi bi-person-gear module-icon"></i>
                        <h5 class="module-title">Usuarios</h5>
                        <p class="text-muted small">Administración</p>
                        <span class="badge bg-dark module-badge"><?= $stats['usuarios'] ?> users</span>
                    </div>
                </a>
            </div>

            <!-- Reportes -->
            <div class="col-md-3">
                <a href="reportes.php" target="blank" class="text-decoration-none text-dark">
                    <div class="module-card">
                        <i class="bi bi-file-earmark-bar-graph module-icon"></i>
                        <h5 class="module-title">Reportes</h5>
                        <p class="text-muted small">Informes y reportes de los préstamos</p>
                    </div>
                </a>
            </div>


            <!-- Préstamos recientes -->
            <div class="card recent-loans mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i>Préstamos recientes</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Equipo</th>
                                    <th>Aprendiz</th>
                                    <th>Fecha préstamo</th>
                                    <th>Fecha devolución</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (mysqli_num_rows($result_prestamos) > 0): ?>
                                    <?php while ($prestamo = mysqli_fetch_assoc($result_prestamos)): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($prestamo['equipo']) ?></td>
                                            <td><?= htmlspecialchars($prestamo['aprendiz']) ?></td>
                                            <td><?= date('d/m/Y', strtotime($prestamo['fecha'])) ?></td>
                                            <td><?= date('d/m/Y', strtotime($prestamo['fechamaxima'])) ?></td>
                                            <td>
                                                <?php
                                                $estado_class = '';
                                                if ($prestamo['estadodevolucion'] == 'Pendiente') {
                                                    if (strtotime($prestamo['fechamaxima']) < time()) {
                                                        $estado_class = 'status-overdue';
                                                        $estado_text = 'Vencido';
                                                    } else {
                                                        $estado_class = 'status-active';
                                                        $estado_text = 'Activo';
                                                    }
                                                } else {
                                                    $estado_class = 'status-pending';
                                                    $estado_text = $prestamo['estadodevolucion'];
                                                }
                                                ?>
                                                <span class="status-badge <?= $estado_class ?>"><?= $estado_text ?></span>
                                            </td>
                                            <td>
                                                <a href="prestamo_modificar.php?idprestamos=<?= $prestamo['idprestamos'] ?>" class="btn btn-sm btn-outline-primary">Detalles</a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-3">No hay préstamos recientes</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pie de página -->
        <footer class="bg-light py-3 border-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <p class="mb-0 text-muted"><i class="bi bi-c-circle"></i> <?= date('Y') ?> Sistema de Préstamos SENA</p>
                    </div>
                </div>
            </div>
        </footer>

        <!-- Efecto de onda decorativo -->
        <div class="wave-decoration"></div>

        <!-- Scripts -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            // Animación para las tarjetas al cargar la página
            document.addEventListener('DOMContentLoaded', function() {
                const cards = document.querySelectorAll('.stats-card, .module-card');
                cards.forEach((card, index) => {
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 100 * index);
                });
            });
        </script>
</body>

</html>