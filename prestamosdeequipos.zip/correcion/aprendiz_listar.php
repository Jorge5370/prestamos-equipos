<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}


// Parámetros de paginación
$registros_por_pagina = 5;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($pagina_actual - 1) * $registros_por_pagina;

// Búsqueda
$busqueda = "";
$where = "";
if (!empty($_GET['buscar'])) {
    $busqueda = mysqli_real_escape_string($conn, $_GET['buscar']);
    $where = "WHERE nombres LIKE '%$busqueda%' OR apellidos LIKE '%$busqueda%'";
}

// Total registros
$total_resultado = mysqli_query($conn, "SELECT COUNT(*) AS total FROM aprendiz $where");
$total_filas = mysqli_fetch_assoc($total_resultado)['total'];
$total_paginas = ceil($total_filas / $registros_por_pagina);

// Consulta principal
$sql = "SELECT * FROM aprendiz $where ORDER BY idaprendiz DESC LIMIT $inicio, $registros_por_pagina";
$resultado = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Aprendices SENA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<?php include 'barraDeNavegacion.php' ?>


    <div class="container mt-5">
        <h2 class="text-center mb-4">Lista de Aprendices</h2>

        <div class="d-flex justify-content-between mb-3">
            <div>
                <a href="index.php" class="btn btn-outline-secondary me-2">Volver al Menú</a>
                <a href="aprendiz_nuevo.php" class="btn btn-primary">➕ Nuevo</a>
            </div>
            <form class="d-flex" method="get">
                <input type="text" name="buscar" class="form-control me-2" placeholder="Buscar..." value="<?= htmlspecialchars($busqueda) ?>">
                <button type="submit" class="btn btn-outline-success">Buscar</button>
            </form>
        </div>

        <table class="table table-bordered table-striped text-center align-middle">
            <thead class="table-primary">
                <tr>
                    <th>Cédula</th>
                    <th>Tipo Documento</th>
                    <th>Nombres</th>
                    <th>Apellidos</th>
                    <th>Celular</th>
                    <th>Email</th>
                    <th>Ficha</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($resultado)) { ?>
                    <tr>
                        <td><?= $row['idaprendiz'] ?></td>
                        <td><?= $row['tipodoc'] ?></td>
                        <td><?= $row['nombres'] ?></td>
                        <td><?= $row['apellidos'] ?></td>
                        <td><?= $row['celular'] ?></td>
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['nficha'] ?></td>
                        <td>
                            <a href="aprendiz_modificar.php?idaprendiz=<?= $row['idaprendiz'] ?>" class="btn btn-warning btn-sm">✏️ Editar</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <!-- Paginación -->
        <?php if ($total_paginas > 1): ?>
            <nav>
                <ul class="pagination justify-content-center">
                    <?php if ($pagina_actual > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?pagina=<?= $pagina_actual - 1 ?>&buscar=<?= urlencode($busqueda) ?>">Anterior</a>
                        </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                        <li class="page-item <?= ($i == $pagina_actual) ? 'active' : '' ?>">
                            <a class="page-link" href="?pagina=<?= $i ?>&buscar=<?= urlencode($busqueda) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($pagina_actual < $total_paginas): ?>
                        <li class="page-item">
                            <a class="page-link" href="?pagina=<?= $pagina_actual + 1 ?>&buscar=<?= urlencode($busqueda) ?>">Siguiente</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>