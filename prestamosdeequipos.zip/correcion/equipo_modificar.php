<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}



if (isset($_GET['idequipo'])) {
    $idequipo = $_GET['idequipo'];
    $resultado = $conn->query("SELECT * FROM equipo WHERE idequipo = '$idequipo'");
    $equipo = $resultado->fetch_assoc();
}

// Procesar actualización
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idequipo = $_POST['idequipo'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $idcategoria = $_POST['idcategoria'];

    $stmt = $conn->prepare("UPDATE equipo SET nombre = ?, descripcion = ?, idcategoria = ? WHERE idequipo = ?");
    $stmt->bind_param("ssii", $nombre, $descripcion, $idcategoria, $idequipo);

    if ($stmt->execute()) {
        header("Location: equipo_listar.php");
        exit();
    } else {
        echo "Error al actualizar: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Modificar Equipo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<?php include 'barraDeNavegacion.php' ?>

<div class="container py-4">
    <div class="card shadow-lg mx-auto" style="max-width: 500px;">
        <div class="card-body p-4">
            <h2 class="text-center mb-4">Modificar Equipo</h2>

            <form method="post">
                <input type="hidden" name="idequipo" value="<?= htmlspecialchars($equipo['idequipo']) ?>">

                <div class="mb-3">
                    <label for="nombre" class="form-label">Nombre</label>
                    <input type="text" id="nombre" name="nombre" class="form-control" value="<?= htmlspecialchars($equipo['nombre']) ?>" required>
                </div>

                <div class="mb-3">
                    <label for="descripcion" class="form-label">Descripción</label>
                    <textarea id="descripcion" name="descripcion" rows="3" class="form-control" required><?= htmlspecialchars($equipo['descripcion']) ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="idcategoria" class="form-label">Categoría</label>
                    <select id="idcategoria" name="idcategoria" class="form-select" required>
                        <option value="">-- Selecciona una categoría --</option>
                        <?php
                        $categorias = $conn->query("SELECT * FROM categorias ORDER BY descripcion");
                        while ($cat = $categorias->fetch_assoc()) {
                            $selected = ($cat['idcategoria'] == $equipo['idcategoria']) ? 'selected' : '';
                            echo "<option value='{$cat['idcategoria']}' $selected>{$cat['descripcion']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a href="equipo_listar.php" class="btn btn-outline-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
