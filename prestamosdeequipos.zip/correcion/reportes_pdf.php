<?php
require('fpdf186/fpdf.php');
include 'db.php';

// Consulta de préstamos con información relacionada
$sql = "SELECT 
            p.idprestamos,
            e.nombre AS equipo,
            CONCAT(a.nombres, ' ', a.apellidos) AS aprendiz,
            p.fecha,
            p.fechamaxima,
            p.fechadevolucion,
            p.estadoentrega,
            p.estadodevolucion,
            u.nombre AS usuario
        FROM prestamos p
        INNER JOIN equipo e ON p.idequipo = e.idequipo
        INNER JOIN aprendiz a ON p.idaprendiz = a.idaprendiz
        INNER JOIN usuarios u ON p.usuario = u.usuario";
$result = mysqli_query($conn, $sql);

// Crear PDF
$pdf = new FPDF();
$pdf->AddPage('L'); // Orientación horizontal para acomodar más columnas
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,'Listado de Préstamos',0,1,'C');
$pdf->Ln(5);

// Cabecera
$pdf->SetFont('Arial','B',9); // Tamaño de fuente más pequeño para cabecera
$pdf->Cell(10,10,'ID',1);
$pdf->Cell(30,10,'Equipo',1);
$pdf->Cell(40,10,'Aprendiz',1);
$pdf->Cell(30,10,'Fecha Préstamo',1);
$pdf->Cell(30,10,'Fecha Máxima',1);
$pdf->Cell(30,10,'Fecha Devolución',1);
$pdf->Cell(25,10,'Estado Entrega',1);
$pdf->Cell(32,10,'Estado Devolución',1);
$pdf->Cell(30,10,'Usuario',1);
$pdf->Ln();

// Datos
$pdf->SetFont('Arial','',8); // Tamaño de fuente más pequeño para datos
while ($row = mysqli_fetch_assoc($result)) {
    $pdf->Cell(10,10,$row['idprestamos'],1);
    $pdf->Cell(30,10,$row['equipo'],1);
    $pdf->Cell(40,10,$row['aprendiz'],1);
    $pdf->Cell(30,10,$row['fecha'],1);
    $pdf->Cell(30,10,$row['fechamaxima'],1);
    $pdf->Cell(30,10,$row['fechadevolucion'],1);
    $pdf->Cell(25,10,$row['estadoentrega'],1);
    $pdf->Cell(32,10,$row['estadodevolucion'],1);
    $pdf->Cell(30,10,$row['usuario'],1);
    $pdf->Ln();
}

$pdf->Output('I', 'prestamos.pdf');
?>