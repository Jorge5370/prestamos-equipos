<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}


// Insertar datos
$mensaje = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idequipo = $_POST['idequipo'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $idcategoria = $_POST['idcategoria'];

    $insertarEquipo = $conn->prepare(
        "INSERT INTO equipo (idequipo, nombre, descripcion, idcategoria) VALUES (?, ?, ?, ?)"
    );

    $insertarEquipo->bind_param("sssi", $idequipo, $nombre, $descripcion, $idcategoria);

    if ($insertarEquipo->execute()) {
        $mensaje = "<div class='alert alert-success text-center'>Equipo registrado correctamente.</div>";
    } else {
        $mensaje = "<div class='alert alert-danger text-center'>Error: " . $insertarEquipo->error . "</div>";
    }

    $insertarEquipo->close();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Registrar Equipo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <?php include 'barraDeNavegacion.php'; ?>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">

                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h3 class="text-center mb-4">Registrar Equipo</h3>
                        <?php if (!empty($mensaje)) echo $mensaje; ?>

                        <form method="post">

                            <div class="mb-3">
                                <label for="idequipo" class="form-label">ID Equipo</label>
                                <input type="text" name="idequipo" id="idequipo" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label for="nombre" class="form-label">Nombre</label>
                                <input type="text" name="nombre" id="nombre" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label for="descripcion" class="form-label">Descripción</label>
                                <textarea name="descripcion" id="descripcion" class="form-control" rows="3" required></textarea>
                            </div>

                            <div class="mb-4">
                                <label for="idcategoria" class="form-label">Categoría</label>
                                <select name="idcategoria" id="idcategoria" class="form-select" required>
                                    <option value="" disabled selected>-- Selecciona una categoría --</option>
                                    <?php
                                    $categorias = $conn->query("SELECT idcategoria, descripcion FROM categorias ORDER BY descripcion");
                                    while ($row = $categorias->fetch_assoc()) {
                                        echo "<option value='{$row['idcategoria']}'>{$row['descripcion']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <!-- Botones -->
                            <div class="d-flex justify-content-between">
                                <a href="equipo_listar.php" class="btn btn-outline-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>