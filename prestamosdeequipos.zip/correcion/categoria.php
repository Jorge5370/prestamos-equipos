<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}



// Configuración de búsqueda y paginación
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$perPage = 5;
$page = isset($_GET['page']) ? max((int)$_GET['page'], 1) : 1;
$offset = ($page - 1) * $perPage;

// Conteo total
$countSql = "SELECT COUNT(*) as total FROM categorias WHERE descripcion LIKE ?";
$stmt = $conn->prepare($countSql);
$param = "%$search%";
$stmt->bind_param('s', $param);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['total'];
$stmt->close();

// Obtener resultados
$sql = "SELECT * FROM categorias WHERE descripcion LIKE ? ORDER BY idcategoria ASC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('sii', $param, $perPage, $offset);
$stmt->execute();
$resultado = $stmt->get_result();

$totalPages = ceil($total / $perPage);

// Mostrar mensajes para formulario
$mensaje = "";
$claseMensaje = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $descripcion = trim($_POST['descripcion'] ?? '');
    if ($descripcion) {
        $insert = $conn->prepare("INSERT INTO categorias (descripcion) VALUES (?)");
        $insert->bind_param('s', $descripcion);
        if ($insert->execute()) {
            $mensaje = "Categoría agregada correctamente.";
            $claseMensaje = "alert-success";
        } else {
            $mensaje = "Error al guardar categoría.";
            $claseMensaje = "alert-danger";
        }
        $insert->close();
    } else {
        $mensaje = "La descripción es obligatoria.";
        $claseMensaje = "alert-warning";
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Categorías</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<?php include 'barraDeNavegacion.php' ?>

    <div class="container py-4">

        <!-- Botón Volver -->
        <a href="index.php" class="btn btn-secondary mb-3">← Volver al menú</a>

        <!-- Formulario para agregar categoría -->
        <div class="card p-3 mb-4">
            <h2 class="text-center mb-3">Agregar Categoría</h2>
            <?php if ($mensaje): ?>
                <div class="alert <?= $claseMensaje; ?>" role="alert"><?= $mensaje; ?></div>
            <?php endif; ?>
            <form method="post" action="">
                <div class="mb-3">
                    <label for="descripcion" class="form-label">Descripción</label>
                    <input type="text" name="descripcion" id="descripcion" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Agregar</button>
            </form>
        </div>

        <!-- Buscador -->
        <form method="get" class="row mb-3">
            <div class="col-auto flex-grow-1">
                <input type="text" name="search" class="form-control" placeholder="Buscar por descripción..." value="<?= htmlspecialchars($search); ?>">
            </div>
            <div class="col-auto">
                <button class="btn btn-outline-primary">Buscar</button>
            </div>
        </form>

        <!-- Tabla -->
        <div class="table-responsive mb-3">
            <table class="table table-bordered table-hover align-middle text-center">
                <thead class="table-primary">
                    <tr>
                        <th>ID Categoría</th>
                        <th>Descripción</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($resultado->num_rows > 0): ?>
                        <?php while ($row = $resultado->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['idcategoria']) ?></td>
                                <td><?= htmlspecialchars($row['descripcion']) ?></td>
                                <td><a href="categoria_editar.php?idcategoria=<?= urlencode($row['idcategoria']) ?>" class="btn btn-warning btn-sm">✏️ Editar</a></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="2" class="text-center text-muted">No hay categorías registradas.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Paginación -->
        <nav class="d-flex justify-content-center mb-3">
            <ul class="pagination">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?search=<?= urlencode($search) ?>&page=<?= $page-1 ?>">Anterior</a>
                </li>
                <?php for ($i=1; $i<=$totalPages; $i++): ?>
                    <li class="page-item <?= $i==$page ? 'active' : '' ?>">
                        <a class="page-link" href="?search=<?= urlencode($search) ?>&page=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?search=<?= urlencode($search) ?>&page=<?= $page+1 ?>">Siguiente</a>
                </li>
            </ul>
        </nav>

    </div>
</body>

</html>
