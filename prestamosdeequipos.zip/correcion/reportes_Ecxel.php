<?php
include 'db.php';

// Configurar headers para exportación Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=reporte_prestamos.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Crear tabla HTML para Excel
echo "<table border='1'>";
echo "<tr>";
echo "<th>ID Préstamo</th>";
echo "<th>Equipo</th>";
echo "<th>Aprendiz</th>";
echo "<th>Fecha Préstamo</th>";
echo "<th>Fecha Máxima</th>";
echo "<th>Fecha Devolución</th>";
echo "<th>Estado Entrega</th>";
echo "<th>Estado Devolución</th>";
echo "<th>Usuario Registro</th>";
echo "</tr>";

// Consulta de préstamos
$sql = "SELECT 
            p.idprestamos,
            e.nombre AS equipo,
            CONCAT(a.nombres, ' ', a.apellidos) AS aprendiz,
            p.fecha,
            p.fechamaxima,
            p.fechadevolucion,
            p.estadoentrega,
            p.estadodevolucion,
            u.nombre AS usuario
        FROM prestamos p
        INNER JOIN equipo e ON p.idequipo = e.idequipo
        INNER JOIN aprendiz a ON p.idaprendiz = a.idaprendiz
        INNER JOIN usuarios u ON p.usuario = u.usuario";

$resultado = mysqli_query($conn, $sql);

// Imprimir resultados
while ($row = mysqli_fetch_assoc($resultado)) {
    echo "<tr>";
    echo "<td>{$row['idprestamos']}</td>";
    echo "<td>{$row['equipo']}</td>";
    echo "<td>{$row['aprendiz']}</td>";
    echo "<td>{$row['fecha']}</td>";
    echo "<td>{$row['fechamaxima']}</td>";
    echo "<td>{$row['fechadevolucion']}</td>";
    echo "<td>{$row['estadoentrega']}</td>";
    echo "<td>{$row['estadodevolucion']}</td>";
    echo "<td>{$row['usuario']}</td>";
    echo "</tr>";
}

echo "</table>";
?>