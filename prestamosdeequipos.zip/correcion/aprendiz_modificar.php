<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}


if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = $_POST['idaprendiz'];
    $tipodoc = $_POST['tipodoc'];
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $celular = $_POST['celular'];
    $email = $_POST['email'];
    $nficha = $_POST['nficha'];

    $sql = "UPDATE aprendiz SET 
                tipodoc='$tipodoc',
                nombres='$nombres',
                apellidos='$apellidos',
                celular='$celular',
                email='$email',
                nficha='$nficha'
            WHERE idaprendiz = '$id'";

    if (mysqli_query($conn, $sql)) {
        header("Location: aprendiz_listar.php");
        exit();
    } else {
        $error = "Error al actualizar: " . mysqli_error($conn);
    }
}

// Consultar los datos del aprendiz
$id = $_GET['idaprendiz'];
$resultado = mysqli_query($conn, "SELECT * FROM aprendiz WHERE idaprendiz = '$id'");
$datos = mysqli_fetch_assoc($resultado);

// Consultar todas las fichas de la base
$fichas = mysqli_query($conn, "SELECT nficha FROM ficha ORDER BY nficha");
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Editar Aprendiz</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <?php include 'barraDeNavegacion.php'; ?>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">

                <!-- Card -->
                <div class="card shadow-sm">
                    <div class="card-body p-4">

                        <h3 class="text-center mb-4">Editar Aprendiz</h3>

                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php endif; ?>

                        <form method="post">
                            <input type="hidden" name="idaprendiz" value="<?= $datos['idaprendiz'] ?>">

                            <!-- Tipo de documento -->
                            <div class="mb-3">
                                <label class="form-label">Tipo de Documento</label>
                                <select name="tipodoc" class="form-select" required>
                                    <option value="CC" <?= $datos['tipodoc'] == 'CC' ? 'selected' : '' ?>>Cédula de Ciudadanía</option>
                                    <option value="TI" <?= $datos['tipodoc'] == 'TI' ? 'selected' : '' ?>>Tarjeta de Identidad</option>
                                    <option value="CE" <?= $datos['tipodoc'] == 'CE' ? 'selected' : '' ?>>Cédula de Extranjería</option>
                                </select>
                            </div>

                            <!-- Nombres -->
                            <div class="mb-3">
                                <label class="form-label">Nombres</label>
                                <input type="text" name="nombres" value="<?= $datos['nombres'] ?>" class="form-control" required>
                            </div>

                            <!-- Apellidos -->
                            <div class="mb-3">
                                <label class="form-label">Apellidos</label>
                                <input type="text" name="apellidos" value="<?= $datos['apellidos'] ?>" class="form-control" required>
                            </div>

                            <!-- Celular -->
                            <div class="mb-3">
                                <label class="form-label">Celular</label>
                                <input type="text" name="celular" value="<?= $datos['celular'] ?>" class="form-control" required>
                            </div>

                            <!-- Email -->
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" value="<?= $datos['email'] ?>" class="form-control" required>
                            </div>

                            <!-- Ficha -->
                            <div class="mb-4">
                                <label class="form-label">Número de Ficha</label>
                                <select name="nficha" class="form-select" required>
                                    <option value="" disabled>-- Selecciona una ficha --</option>
                                    <?php while ($ficha = mysqli_fetch_assoc($fichas)) : ?>
                                        <option value="<?= $ficha['nficha'] ?>" <?= $datos['nficha'] == $ficha['nficha'] ? 'selected' : '' ?>>
                                            <?= $ficha['nficha'] ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>

                            <!-- Botones -->
                            <div class="d-flex justify-content-between">
                                <a href="aprendiz_listar.php" class="btn btn-outline-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Actualizar</button>
                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
