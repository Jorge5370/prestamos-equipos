<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}


// Parámetros de paginación
$registros_por_pagina = 5;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
if ($pagina_actual < 1) $pagina_actual = 1;
$inicio = ($pagina_actual - 1) * $registros_por_pagina;

// Búsqueda
$busqueda = "";
$where = "";
if (!empty($_GET['buscar'])) {
    $busqueda = mysqli_real_escape_string($conn, $_GET['buscar']);
    $where = "WHERE e.nombre LIKE '%$busqueda%' OR a.nombres LIKE '%$busqueda%' OR a.apellidos LIKE '%$busqueda%' OR u.nombre LIKE '%$busqueda%' OR p.estadodevolucion LIKE '%$busqueda%'";
}

// Total registros
$total_resultado = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM prestamos p
     INNER JOIN equipo e ON p.idequipo = e.idequipo
     INNER JOIN aprendiz a ON p.idaprendiz = a.idaprendiz
     INNER JOIN usuarios u ON p.usuario = u.usuario
     $where"
);
$total_filas = mysqli_fetch_assoc($total_resultado)['total'];
$total_paginas = max(1, ceil($total_filas / $registros_por_pagina));

// Consulta con LIMIT y búsqueda
$sql = "SELECT 
            p.idprestamos,
            e.nombre AS equipo,
            CONCAT(a.nombres, ' ', a.apellidos) AS aprendiz,
            p.fecha,
            p.fechamaxima,
            p.fechadevolucion,
            p.estadoentrega,
            p.estadodevolucion,
            u.nombre AS usuario
        FROM prestamos p
        INNER JOIN equipo e ON p.idequipo = e.idequipo
        INNER JOIN aprendiz a ON p.idaprendiz = a.idaprendiz
        INNER JOIN usuarios u ON p.usuario = u.usuario
        $where
        ORDER BY p.idprestamos DESC
        LIMIT $inicio, $registros_por_pagina";

$resultado = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Listado de Préstamos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <?php include 'barraDeNavegacion.php' ?>


    <div class="container py-4">
        <h2 class="text-center mb-4">Listado de Préstamos</h2>

        <div class="d-flex justify-content-between mb-3">
            <div>
                <a href="index.php" class="btn btn-outline-secondary me-2">Volver al Menú</a>
                <a href="prestamo_nuevo.php" class="btn btn-primary">➕ Nuevo Préstamo</a>
            </div>
            <form class="d-flex" method="get">
                <input type="text" name="buscar" class="form-control me-2" placeholder="Buscar..." value="<?= htmlspecialchars($busqueda) ?>">
                <button class="btn btn-outline-success btn-sm" type="submit">Buscar</button>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-hover table-striped align-middle text-center">
                <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>Fecha Préstamo</th>
                        <th>Equipo</th>
                        <th>Aprendiz</th>
                        <th>Fecha Máxima</th>
                        <th>Estado Entrega</th>
                        <th>Estado Devolución</th>
                        <th>Fecha Devolución</th>
                        <th>Registrado por</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($resultado) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($resultado)): ?>
                            <tr>
                                <td><?= $row['idprestamos'] ?></td>
                                <td><?= $row['fecha'] ?></td>
                                <td><?= htmlspecialchars($row['equipo']) ?></td>
                                <td><?= htmlspecialchars($row['aprendiz']) ?></td>
                                <td><?= $row['fechamaxima'] ?></td>
                                <td><?= $row['estadoentrega'] ?></td>
                                <td><?= $row['estadodevolucion'] ?></td>
                                <td><?= $row['fechadevolucion'] ?: '<span class="text-muted">Sin devolver</span>' ?></td>
                                <td><?= $row['usuario'] ?></td>
                                <td>
                                    <a href="prestamo_modificar.php?idprestamos=<?= urlencode($row['idprestamos']) ?>" class="btn btn-sm btn-warning">Editar</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10">No hay préstamos para mostrar</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>

        <!-- Paginación -->
        <nav>
            <ul class="pagination justify-content-center">
                <!-- Anterior -->
                <li class="page-item <?= $pagina_actual <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?pagina=<?= $pagina_actual - 1 ?>&buscar=<?= urlencode($busqueda) ?>">Anterior</a>
                </li>

                <!-- Números dinámicos -->
                <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                    <li class="page-item <?= $i == $pagina_actual ? 'active' : '' ?>">
                        <a class="page-link" href="?pagina=<?= $i ?>&buscar=<?= urlencode($busqueda) ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>

                <!-- Siguiente -->
                <li class="page-item <?= $pagina_actual >= $total_paginas ? 'disabled' : '' ?>">
                    <a class="page-link" href="?pagina=<?= $pagina_actual + 1 ?>&buscar=<?= urlencode($busqueda) ?>">Siguiente</a>
                </li>
            </ul>
        </nav>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>