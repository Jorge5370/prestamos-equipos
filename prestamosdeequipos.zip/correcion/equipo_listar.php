<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}


// Parámetros de paginación
$registros_por_pagina = 5;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
if ($pagina_actual < 1) $pagina_actual = 1;
$inicio = ($pagina_actual - 1) * $registros_por_pagina;

// Búsqueda
$busqueda = "";
$where = "";
if (!empty($_GET['buscar'])) {
    $busqueda = mysqli_real_escape_string($conn, $_GET['buscar']);
    $where = "WHERE e.nombre LIKE '%$busqueda%' OR e.descripcion LIKE '%$busqueda%' OR c.descripcion LIKE '%$busqueda%'";
}

// Total de registros
$total_resultado = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total FROM equipo e INNER JOIN categorias c ON e.idcategoria = c.idcategoria $where"
);
$total_filas = mysqli_fetch_assoc($total_resultado)['total'];
$total_paginas = max(1, ceil($total_filas / $registros_por_pagina));

// Consulta con LIMIT y búsqueda
$sql = "SELECT e.idequipo, e.nombre, e.descripcion, c.descripcion AS categoria
        FROM equipo e
        INNER JOIN categorias c ON e.idcategoria = c.idcategoria
        $where
        ORDER BY e.idequipo ASC
        LIMIT $inicio, $registros_por_pagina";

$resultado = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Equipos Registrados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <?php include 'barraDeNavegacion.php' ?>


    <div class="container py-4">
        <h2 class="text-center mb-4">Equipos Registrados</h2>

        <div class="d-flex justify-content-between mb-3">
            <div>
                <a href="index.php" class="btn btn-outline-secondary me-2">Volver al Menú</a>
                <a href="equipo.php" class="btn btn-primary">➕ Nuevo Equipo</a>
            </div>
            <form class="d-flex" method="get">
                <input type="text" name="buscar" class="form-control me-2" placeholder="Buscar..." value="<?= htmlspecialchars($busqueda) ?>">
                <button type="submit" class="btn btn-outline-success">Buscar</button>
            </form>
        </div>

        <table class="table table-striped table-bordered table-hover align-middle text-center">
            <thead class="table-primary">
                <tr>
                    <th>ID Equipo</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Categoría</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($resultado) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($resultado)): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['idequipo']) ?></td>
                            <td><?= htmlspecialchars($row['nombre']) ?></td>
                            <td><?= htmlspecialchars($row['descripcion']) ?></td>
                            <td><?= htmlspecialchars($row['categoria']) ?></td>
                            <td>
                                <a href="equipo_modificar.php?idequipo=<?= urlencode($row['idequipo']) ?>" class="btn btn-sm btn-warning">✏️ Editar</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">No hay equipos para mostrar</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Paginación -->
        <nav>
            <ul class="pagination justify-content-center">
                <!-- Anterior -->
                <li class="page-item <?= $pagina_actual <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?pagina=<?= $pagina_actual - 1 ?>&buscar=<?= urlencode($busqueda) ?>">Anterior</a>
                </li>

                <!-- Números dinámicos -->
                <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                    <li class="page-item <?= $i == $pagina_actual ? 'active' : '' ?>">
                        <a class="page-link" href="?pagina=<?= $i ?>&buscar=<?= urlencode($busqueda) ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>

                <!-- Siguiente -->
                <li class="page-item <?= $pagina_actual >= $total_paginas ? 'disabled' : '' ?>">
                    <a class="page-link" href="?pagina=<?= $pagina_actual + 1 ?>&buscar=<?= urlencode($busqueda) ?>">Siguiente</a>
                </li>
            </ul>
        </nav>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>