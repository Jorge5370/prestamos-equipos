<?php
include 'db.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}


$nficha = $_GET['nficha'] ?? '';
if ($nficha) {
    $sql = "SELECT * FROM ficha WHERE nficha = '$nficha'";
    $resultado = mysqli_query($conn, $sql);
    $ficha = mysqli_fetch_assoc($resultado);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nficha = $_POST['nficha'];
    $idprograma = $_POST['idprograma'];

    $sql = "UPDATE ficha SET idprograma = '$idprograma' WHERE nficha = '$nficha'";
    if (mysqli_query($conn, $sql)) {
        header("Location: ficha_listar.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Modificar Ficha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<?php include 'barraDeNavegacion.php' ?>

<div class="container py-4">
    <div class="card shadow-lg mx-auto" style="max-width: 500px;">
        <div class="card-body p-4">
            <h2 class="text-center mb-4">Modificar Ficha</h2>

            <form method="post">
                <!-- Ficha (readonly) -->
                <div class="mb-3">
                    <label for="nficha" class="form-label">Número de Ficha</label>
                    <input type="text" id="nficha" name="nficha" class="form-control" value="<?= htmlspecialchars($ficha['nficha']) ?>" readonly>
                </div>

                <!-- Programa -->
                <div class="mb-3">
                    <label for="idprograma" class="form-label">Programa</label>
                    <select id="idprograma" name="idprograma" class="form-select" required>
                        <option value="">-- Selecciona un programa --</option>
                        <?php
                        $programas = mysqli_query($conn, "SELECT * FROM programa ORDER BY nombreprograma");
                        while ($p = mysqli_fetch_assoc($programas)) {
                            $selected = ($p['idprograma'] == $ficha['idprograma']) ? 'selected' : '';
                            echo "<option value='{$p['idprograma']}' $selected>{$p['nombreprograma']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <!-- Botones -->
                <div class="d-flex justify-content-between mt-4">
                    <a href="ficha_listar.php" class="btn btn-outline-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
